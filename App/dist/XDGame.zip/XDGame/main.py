import graphics


def main():
    mode = 1
    graphics.configure(mode)
    app = graphics.GameApp()
    app.run()


if __name__ == "__main__":
    main()
